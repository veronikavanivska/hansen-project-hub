Hansen Polska - EC 1 Lodz demo package. Fictional presentation files only.
